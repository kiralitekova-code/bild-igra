extends CanvasLayer
